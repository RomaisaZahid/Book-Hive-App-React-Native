import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://daakezbusflyjdocajqj.supabase.co';
const supabaseAnonKey = 'sb_publishable_5Oi_SowfhyUBgXY73lrKWw_KFlfweT_';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
