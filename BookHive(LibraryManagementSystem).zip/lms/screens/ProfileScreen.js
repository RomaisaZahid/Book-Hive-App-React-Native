import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import { LinearGradient } from "expo-linear-gradient";

export default function ProfileScreen({ navigation }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("Admin");

  const handleSave = () => {
    alert("Changes Saved Successfully!");
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>

        {/* Title */} 
        <Text style={styles.title}>👤 Profile Settings</Text>

        {/* Full Name */}
        <Text style={styles.label}>Full Name</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your full name"
          placeholderTextColor="#777"
          value={name}
          onChangeText={setName}
        />

        {/* Email */}
        <Text style={styles.label}>Email Address</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your email"
          placeholderTextColor="#777"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />

        {/* Phone */}
        <Text style={styles.label}>Phone Number</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your phone number"
          placeholderTextColor="#777"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
        />

        {/* Role */}
        <Text style={styles.label}>Role</Text>
        <View style={styles.pickerBox}>
          <Picker
            selectedValue={role}
            onValueChange={setRole}
            style={styles.picker}
            dropdownIconColor="#008080"
          >
            <Picker.Item label="Admin" value="Admin" />
            <Picker.Item label="Librarian" value="Librarian" />
            <Picker.Item label="Intern" value="Intern" />
            <Picker.Item label="Member" value="Member" />
          </Picker>
        </View>

        {/* Save Button */}
        <LinearGradient
          colors={["#00b3b3", "#ffa500"]}
          style={styles.saveBtn}
        >
          <TouchableOpacity onPress={handleSave}>
            <Text style={styles.saveText}>💾 Save Changes</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Back to Settings */}
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backBtn}>⬅ Back to Settings</Text>
        </TouchableOpacity>

      </View>
    </ScrollView>
  );
}

/* ------------------ STYLES ------------------ */

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#E6F4F1",
    justifyContent: "center",
    padding: 20,
  },

  card: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 25,
    elevation: 8,
  },

  title: {
    fontSize: 24,
    fontWeight: "700",
    color: "teal",
    textAlign: "center",
    marginBottom: 25,
  },

  label: {
    fontWeight: "600",
    fontSize: 16,
    color: "#333",
    marginTop: 10,
    marginBottom: 5,
  },

  input: {
    backgroundColor: "#fff",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    fontSize: 15,
    marginBottom: 10,
  },

  pickerBox: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 12,
    marginBottom: 10,
    backgroundColor: "#fff",
  },

  picker: {
    height: 50,
    color: "#008080",
  },

  saveBtn: {
    marginTop: 25,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: "center",
  },

  saveText: {
    color: "white",
    fontSize: 17,
    fontWeight: "600",
  },

  backBtn: {
    textAlign: "center",
    marginTop: 15,
    fontSize: 16,
    fontWeight: "600",
    color: "teal",
  },
});
