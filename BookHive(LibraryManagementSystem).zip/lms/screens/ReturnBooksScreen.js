import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  Alert,
  ScrollView,
} from "react-native";
import { useNavigation, DrawerActions } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";

export default function ReturnBooksScreen() {
  const navigation = useNavigation();

  const [form, setForm] = useState({
    memberId: "",
    memberName: " ",
    bookId: "",
    bookTitle: "",
    issueDate: "",
    returnDate: "",
    condition: "",
  });

  const [returnedBooks, setReturnedBooks] = useState([]);

  const handleInputChange = (field, value) =>
    setForm({ ...form, [field]: value });

  const handleReturn = () => {
    const { memberId, memberName, bookId, bookTitle, issueDate, returnDate, condition } = form;

    if (!memberId || !memberName || !bookId || !bookTitle || !issueDate || !returnDate || !condition) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }

    const newRecord = {
      id: Date.now().toString(),
      memberId,
      memberName,
      bookId,
      bookTitle,
      issueDate,
      returnDate,
      condition,
    };

    setReturnedBooks([newRecord, ...returnedBooks]);

    Alert.alert("📘 Success", `Book "${bookTitle}" returned by ${memberName}`);

    setForm({
      memberId: "",
      memberName: "",
      bookId: "",
      bookTitle: "",
      issueDate: "",
      returnDate: "",
      condition: "",
    });
  };

  return (
    <ScrollView style={styles.container}>
      {/* ---------------- HEADER BAR WITH DRAWER ---------------- */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() =>
            navigation.dispatch(DrawerActions.openDrawer())
          }
        >
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>

        <Text style={styles.headerTitle}>    📘 Return Books</Text>
      </View>

      {/* ---------------- FORM SECTION ---------------- */}
      <View style={styles.formContainer}>
        {[
          { label: "Member ID", key: "memberId" },
          { label: "Member Name", key: "memberName" },
          { label: "Book ID", key: "bookId" },
          { label: "Book Title", key: "bookTitle" },
          { label: "Issue Date (YYYY-MM-DD)", key: "issueDate" },
          { label: "Return Date (YYYY-MM-DD)", key: "returnDate" },
          { label: "Condition on Return", key: "condition", multiline: true, height: 60 },
        ].map((field) => (
          <View key={field.key} style={styles.inputGroup}>
            <Text style={styles.label}>{field.label}</Text>

            <TextInput
              style={[styles.input, field.multiline && { height: field.height }]}
              value={form[field.key]}
              onChangeText={(v) => handleInputChange(field.key, v)}
              multiline={field.multiline || false}
            />
          </View>
        ))}

        <TouchableOpacity style={styles.issueButton} onPress={handleReturn}>
          <Text style={styles.issueButtonText}>✔ Mark as Returned</Text>
        </TouchableOpacity>
      </View>

      {/* ---------------- RETURNED BOOKS LIST ---------------- */}
      {returnedBooks.length > 0 && (
        <View style={styles.listContainer}>
          <Text style={styles.listTitle}>Recently Returned Books</Text>

          <FlatList
            data={returnedBooks}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View style={styles.bookCard}>
                <Text style={[styles.bookField, { color: "#FF7A00" }]}>
                  Member ID: <Text style={styles.bookValue}>{item.memberId}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#008080" }]}>
                  Member Name: <Text style={styles.bookValue}>{item.memberName}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#FF7A00" }]}>
                  Book ID: <Text style={styles.bookValue}>{item.bookId}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#008080" }]}>
                  Book Title: <Text style={styles.bookValue}>{item.bookTitle}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#FF7A00" }]}>
                  Issue Date: <Text style={styles.bookValue}>{item.issueDate}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#008080" }]}>
                  Return Date: <Text style={styles.bookValue}>{item.returnDate}</Text>
                </Text>

                <Text style={[styles.bookField, { color: "#FF7A00" }]}>
                  Condition: <Text style={styles.bookValue}>{item.condition}</Text>
                </Text>
              </View>
            )}
          />
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E6F4F1",
    paddingHorizontal: 15,
    paddingBottom: 20,
  },

  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 12,
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    marginTop: 50,
    marginBottom: 20,
  },

  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#008080",
    marginLeft: 10,
  },

  formContainer: {
    backgroundColor: "#F9F9F9",
    borderRadius: 18,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },

  inputGroup: { marginBottom: 15 },

  label: {
    fontWeight: "600",
    fontSize: 14,
    color: "#008080",
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 15,
    fontSize: 14,
    backgroundColor: "#fff",
  },

  issueButton: {
    backgroundColor: "#FF7A00",
    paddingVertical: 14,
    borderRadius: 30,
    marginTop: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 4,
  },

  issueButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },

  listContainer: {
    marginTop: 25,
  },

  listTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#008080",
    marginBottom: 10,
  },

  bookCard: {
    backgroundColor: "#F9F9F9",
    borderRadius: 15,
    padding: 15,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },

  bookField: { fontWeight: "600", marginBottom: 4 },

  bookValue: { fontWeight: "400", color: "#333" },
});
