import React from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  Animated,
  Alert
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function LogoutScreen({ navigation }) {
  
  // Floating animation
  const floatAnim = new Animated.Value(0);

  React.useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(floatAnim, {
          toValue: -10,
          duration: 2500,
          useNativeDriver: true,
        }),
        Animated.timing(floatAnim, {
          toValue: 0,
          duration: 2500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  // Logout Function
  const logoutUser = async () => {
    try {
      await AsyncStorage.removeItem("authToken");
      await AsyncStorage.setItem("isLoggedIn", "false");

      // Navigate to SignUp screen
      navigation.reset({
        index: 0,
        routes: [{ name: "SignUp" }],
      });
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  // Show confirmation alert
  const confirmLogout = () => {
    Alert.alert(
      "Confirm Logout",
      "You will be logged out from your BookHive account.",
      [
        {
          text: "Cancel",
          onPress: () => navigation.goBack(),
          style: "cancel"
        },
        {
          text: "Logout",
          onPress: logoutUser,
          style: "destructive"
        }
      ]
    );
  };

  // Trigger alert immediately when screen loads
  React.useEffect(() => {
    confirmLogout();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.overlay} />

      <Animated.View style={[styles.card, { transform: [{ translateY: floatAnim }] }]}>
        <Text style={styles.title}>Confirm Logout</Text>
        <Text style={styles.subtitle}>You will be logged out from your BookHive account.</Text>

        <TouchableOpacity style={styles.btnLogout} onPress={logoutUser}>
          <Text style={styles.btnText}>Logout</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btnCancel} onPress={() => navigation.goBack()}>
          <Text style={styles.btnText}>Cancel</Text>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#008080", // Optional background color instead of image
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  card: {
    width: "88%",
    backgroundColor: "rgba(255,255,255,0.95)",
    padding: 25,
    borderRadius: 15,
    alignItems: "center",
    elevation: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 8,
    color: "#222",
  },
  subtitle: {
    textAlign: "center",
    color: "#444",
    marginBottom: 20,
  },
  btnLogout: {
    width: "100%",
    padding: 12,
    borderRadius: 10,
    backgroundColor: "#ff3939",
    marginBottom: 10,
  },
  btnCancel: {
    width: "100%",
    padding: 12,
    borderRadius: 10,
    backgroundColor: "#555",
  },
  btnText: {
    textAlign: "center",
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },
});
 