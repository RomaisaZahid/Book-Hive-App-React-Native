import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Modal,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "LIBRARY_BOOKS";

export default function BooksScreen() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState("");

  const [modalVisible, setModalVisible] = useState(false);
  const [editingBook, setEditingBook] = useState(null);

  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    category: "",
    quantity: "",
  });

  // 🔹 LOAD BOOKS
  const loadBooks = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) setBooks(JSON.parse(stored));
    } catch {
      Alert.alert("Error", "Failed to load books");
    }
  };

  useEffect(() => {
    loadBooks();
  }, []);

  // 🔹 SAVE BOOKS
  const saveBooks = async (data) => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  };

  // 🔹 ADD OR UPDATE BOOK
  const saveBook = async () => {
    const { title, author, category, quantity } = newBook;

    if (!title || !author || !category || !quantity) {
      Alert.alert("Error", "Fill all fields");
      return;
    }

    const qty = Number(quantity);
    if (isNaN(qty)) {
      Alert.alert("Error", "Quantity must be a number");
      return;
    }

    let updatedBooks;

    if (editingBook) {
      // ✏️ UPDATE
      updatedBooks = books.map((b) =>
        b.id === editingBook.id
          ? { ...b, title, author, category, quantity: qty }
          : b
      );
    } else {
      // ➕ ADD
      const book = {
        id: Date.now().toString(),
        title,
        author,
        category,
        quantity: qty,
        created_at: new Date().toISOString(),
      };
      updatedBooks = [book, ...books];
    }

    setBooks(updatedBooks);
    await saveBooks(updatedBooks);

    setModalVisible(false);
    setEditingBook(null);
    setNewBook({ title: "", author: "", category: "", quantity: "" });
  };

  // 🔹 DELETE
  const deleteBook = (id) => {
    Alert.alert("Delete Book?", "Are you sure?", [
      { text: "Cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          const updated = books.filter((b) => b.id !== id);
          setBooks(updated);
          await saveBooks(updated);
        },
      },
    ]);
  };

  // 🔹 EDIT
  const startEdit = (book) => {
    setEditingBook(book);
    setNewBook({
      title: book.title,
      author: book.author,
      category: book.category,
      quantity: String(book.quantity),
    });
    setModalVisible(true);
  };

  // 🔍 SEARCH FILTER
  const filteredBooks = books.filter(
    (b) =>
      b.title.toLowerCase().includes(search.toLowerCase()) ||
      b.author.toLowerCase().includes(search.toLowerCase()) ||
      b.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📚 Library Books</Text>

      {/* 🔍 SEARCH */}
      <TextInput
        placeholder="Search by title, author, category..."
        value={search}
        onChangeText={setSearch}
        style={styles.search}
      />

      <FlatList
        data={filteredBooks}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View>
              <Text style={styles.text}>Title: {item.title}</Text>
              <Text style={styles.text}>Author: {item.author}</Text>
              <Text style={styles.text}>Category: {item.category}</Text>
              <Text style={styles.text}>Quantity: {item.quantity}</Text>
            </View>

            <View style={{ flexDirection: "row" }}>
              <TouchableOpacity onPress={() => startEdit(item)}>
                <Ionicons name="create" size={22} color="#008080" />
              </TouchableOpacity>

              <TouchableOpacity onPress={() => deleteBook(item.id)}>
                <Ionicons
                  name="trash"
                  size={22}
                  color="red"
                  style={{ marginLeft: 12 }}
                />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {/* ➕ BUTTON */}
      <TouchableOpacity
        style={styles.addBtn}
        onPress={() => {
          setEditingBook(null);
          setNewBook({ title: "", author: "", category: "", quantity: "" });
          setModalVisible(true);
        }}
      >
        <Ionicons name="add" size={28} color="#fff" />
      </TouchableOpacity>

      {/* MODAL */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modal}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>
              {editingBook ? "Edit Book" : "Add Book"}
            </Text>

            {["title", "author", "category", "quantity"].map((key) => (
              <TextInput
                key={key}
                placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                value={newBook[key]}
                keyboardType={key === "quantity" ? "numeric" : "default"}
                onChangeText={(t) => setNewBook({ ...newBook, [key]: t })}
                style={styles.input}
              />
            ))}

            <TouchableOpacity style={styles.saveBtn} onPress={saveBook}>
              <Text style={styles.saveText}>
                {editingBook ? "Update" : "Add"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.cancelBtn}
              onPress={() => setModalVisible(false)}
            >
              <Text style={{ color: "red" }}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: "700" },
  search: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    borderRadius: 8,
    marginVertical: 10,
  },
  card: {
    backgroundColor: "#eee",
    padding: 12,
    marginVertical: 6,
    borderRadius: 8,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  text: { fontSize: 14 },
  addBtn: {
    backgroundColor: "#008080",
    width: 60,
    height: 60,
    borderRadius: 30,
    position: "absolute",
    bottom: 20,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    flex: 1,
    justifyContent: "center",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalBox: {
    backgroundColor: "#fff",
    margin: 20,
    padding: 20,
    borderRadius: 10,
  },
  modalTitle: { fontSize: 18, fontWeight: "700", marginBottom: 10 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    padding: 10,
    borderRadius: 6,
    marginBottom: 10,
  },
  saveBtn: {
    backgroundColor: "#008080",
    padding: 12,
    borderRadius: 6,
    alignItems: "center",
  },
  saveText: { color: "#fff", fontWeight: "600" },
  cancelBtn: { alignItems: "center", marginTop: 10 },
});
