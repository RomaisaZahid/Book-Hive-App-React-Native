import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "LIBRARY_MEMBERS";

export default function MembersScreen({ navigation }) {
  const [members, setMembers] = useState([]);
  const [newMember, setNewMember] = useState({
    firstName: "",
    lastName: "",
    semester: "",
    course: "",
    degree: "",
    email: "",
    phone: "",
    membershipType: "",
    from: "",
    to: "",
    reason: "",
  });

  // ----------------------------------------------------
  // LOAD MEMBERS FROM ASYNC STORAGE
  // ----------------------------------------------------
  const loadMembers = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setMembers(JSON.parse(stored));
      }
    } catch (error) {
      Alert.alert("Error", "Failed to load members");
    }
  };

  useEffect(() => {
    loadMembers();
  }, []);

  // ----------------------------------------------------
  // SAVE MEMBERS TO ASYNC STORAGE
  // ----------------------------------------------------
  const saveMembers = async (data) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      Alert.alert("Error", "Failed to save members");
    }
  };

  // ----------------------------------------------------
  // ADD MEMBER (LOCAL)
  // ----------------------------------------------------
  const addMember = async () => {
    const values = Object.values(newMember);
    if (values.some((v) => !v)) {
      Alert.alert("Error", "Please fill all fields!");
      return;
    }

    const member = {
      id: Date.now().toString(),
      first_name: newMember.firstName,
      last_name: newMember.lastName,
      semester: newMember.semester,
      course: newMember.course,
      degree: newMember.degree,
      email: newMember.email,
      phone: newMember.phone,
      membership_type: newMember.membershipType,
      from_date: newMember.from,
      to_date: newMember.to,
      reason: newMember.reason,
      created_at: new Date().toISOString(),
    };

    const updatedMembers = [...members, member];
    setMembers(updatedMembers);
    await saveMembers(updatedMembers);

    setNewMember({
      firstName: "",
      lastName: "",
      semester: "",
      course: "",
      degree: "",
      email: "",
      phone: "",
      membershipType: "",
      from: "",
      to: "",
      reason: "",
    });

    Alert.alert("Success", "Member added successfully!");
  };

  // ----------------------------------------------------
  // DELETE MEMBER
  // ----------------------------------------------------
  const deleteMember = async (id) => {
    Alert.alert("Delete Member", "Are you sure?", [
      { text: "Cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          const updated = members.filter((m) => m.id !== id);
          setMembers(updated);
          await saveMembers(updated);
        },
      },
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() => navigation.toggleDrawer()}
          style={styles.drawerIcon}
        >
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>📋 Manage Members (Offline)</Text>
      </View>

      {/* Form */}
      <View style={styles.formContainer}>
        {[
          { label: "First Name", key: "firstName" },
          { label: "Last Name", key: "lastName" },
          { label: "Semester", key: "semester" },
          { label: "Course", key: "course" },
          { label: "Degree", key: "degree" },
          { label: "Email", key: "email" },
          { label: "Phone", key: "phone" },
          { label: "Membership Type", key: "membershipType" },
          { label: "From", key: "from" },
          { label: "To", key: "to" },
        ].map((field) => (
          <View key={field.key} style={styles.inputGroup}>
            <Text style={styles.label}>{field.label}</Text>
            <TextInput
              style={styles.input}
              value={newMember[field.key]}
              onChangeText={(text) =>
                setNewMember({ ...newMember, [field.key]: text })
              }
            />
          </View>
        ))}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Reason / Objective</Text>
          <TextInput
            style={[styles.input, { height: 60 }]}
            multiline
            value={newMember.reason}
            onChangeText={(text) =>
              setNewMember({ ...newMember, reason: text })
            }
          />
        </View>

        <TouchableOpacity style={styles.addButton} onPress={addMember}>
          <Text style={styles.addButtonText}>➕ Add Member</Text>
        </TouchableOpacity>
      </View>

      {/* List */}
      {members.length > 0 && (
        <View style={styles.listContainer}>
          <Text style={styles.listTitle}>Members List</Text>

          <FlatList
            data={members}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.memberCard}>
                <Text style={styles.memberField}>
                  Name:{" "}
                  <Text style={styles.memberValue}>
                    {item.first_name} {item.last_name}
                  </Text>
                </Text>

                <Text style={styles.memberField}>
                  Course:{" "}
                  <Text style={styles.memberValue}>{item.course}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Semester:{" "}
                  <Text style={styles.memberValue}>{item.semester}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Degree:{" "}
                  <Text style={styles.memberValue}>{item.degree}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Email:{" "}
                  <Text style={styles.memberValue}>{item.email}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Phone:{" "}
                  <Text style={styles.memberValue}>{item.phone}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Membership Type:{" "}
                  <Text style={styles.memberValue}>
                    {item.membership_type}
                  </Text>
                </Text>

                <Text style={styles.memberField}>
                  From:{" "}
                  <Text style={styles.memberValue}>{item.from_date}</Text>
                </Text>

                <Text style={styles.memberField}>
                  To:{" "}
                  <Text style={styles.memberValue}>{item.to_date}</Text>
                </Text>

                <Text style={styles.memberField}>
                  Reason:{" "}
                  <Text style={styles.memberValue}>{item.reason}</Text>
                </Text>

                <TouchableOpacity
                  onPress={() => deleteMember(item.id)}
                  style={{ marginTop: 8 }}
                >
                  <Ionicons name="trash" size={22} color="red" />
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      )}
    </ScrollView>
  );
}

// --------------------------- STYLES ------------------------------
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E6F4F1",
    paddingHorizontal: 15,
    paddingBottom: 20,
  },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 12,
    elevation: 4,
    marginTop: 50,
    marginBottom: 20,
  },
  drawerIcon: { width: 40 },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#004D4D",
    marginLeft: 10,
  },
  formContainer: {
    backgroundColor: "#F9F9F9",
    borderRadius: 18,
    padding: 20,
    elevation: 3,
    marginBottom: 25,
  },
  inputGroup: { marginBottom: 15 },
  label: {
    fontWeight: "600",
    fontSize: 14,
    color: "#00575B",
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 15,
    fontSize: 14,
    backgroundColor: "#fff",
  },
  addButton: {
    backgroundColor: "#FF7A00",
    paddingVertical: 14,
    borderRadius: 30,
    alignItems: "center",
    marginTop: 10,
  },
  addButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },
  listContainer: { marginBottom: 30 },
  listTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#004D4D",
    marginBottom: 10,
  },
  memberCard: {
    backgroundColor: "#F9F9F9",
    borderRadius: 15,
    padding: 15,
    marginBottom: 12,
    elevation: 2,
  },
  memberField: { fontWeight: "600", marginBottom: 4 },
  memberValue: { fontWeight: "400", color: "#222" },
});
