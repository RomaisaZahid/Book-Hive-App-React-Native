import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Modal,
} from "react-native";

export default function SettingsScreen({ navigation }) {
  const [darkMode, setDarkMode] = useState(false);
  const [helpModalVisible, setHelpModalVisible] = useState(false);

  const toggleTheme = () => setDarkMode(!darkMode);

  return (
    <View style={[styles.container, darkMode && styles.darkContainer]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        {/* Heading Bar */}
        <View style={[styles.headingBar, darkMode && styles.darkHeadingBar]}>
          <Text style={[styles.title, darkMode && styles.darkTitle]}>
            ⚙️ Settings Panel
          </Text>
        </View>

        {/* Subtitle */}
        <Text style={[styles.subtitle, darkMode && styles.darkSubtitle]}>
          Cus tomize your BookHive experience — manage your profile and themes.
        </Text>

        {/* Buttons */}
        <View style={styles.buttonsContainer}>
          
          {/* Profile Settings */}
          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate("Profile")}
          >
            <Text style={styles.buttonText}>👤 Profile Settings</Text>
          </TouchableOpacity>

          {/* Theme Toggle */}
          <TouchableOpacity style={styles.button} onPress={toggleTheme}>
            <Text style={styles.buttonText}>🌙 Switch Theme</Text>
          </TouchableOpacity>

          {/* Help */}
          <TouchableOpacity
            style={styles.button}
            onPress={() => setHelpModalVisible(true)}
          >
            <Text style={styles.buttonText}>❓ Help & Guide</Text>
          </TouchableOpacity>

          {/* Back to Dashboard */}
          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate("Dashboard")}
          >
            <Text style={styles.buttonText}>🏠 Back to Dashboard</Text>
          </TouchableOpacity>
        </View>

        <Text style={[styles.footerText, darkMode && styles.darkFooter]}>
          © 2025 BookHive — Library Management System
        </Text>
      </ScrollView>

      {/* HELP MODAL */}
      <Modal
        visible={helpModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setHelpModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalContent,
              darkMode && styles.darkModalContent,
            ]}
          >
            <Text style={[styles.modalTitle, darkMode && styles.darkTitle]}>
              📘 BookHive Help & Guide
            </Text>

            <Text style={[styles.modalText, darkMode && styles.darkText]}>
              Welcome to <Text style={{ fontWeight: "700" }}>BookHive</Text> — your all-in-one library management system!
            </Text>

            <View style={{ marginVertical: 10 }}>
              <Text style={[styles.modalText, darkMode && styles.darkText]}>• Dashboard: View statistics & activity.</Text>
              <Text style={[styles.modalText, darkMode && styles.darkText]}>• Books: Manage book inventory.</Text>
              <Text style={[styles.modalText, darkMode && styles.darkText]}>• Members: Handle member records.</Text>
              <Text style={[styles.modalText, darkMode && styles.darkText]}>• Issued Books: Track issued/returned books.</Text>
              <Text style={[styles.modalText, darkMode && styles.darkText]}>• Settings: Customize your experience.</Text>
            </View>

            <TouchableOpacity
              style={[
                styles.modalButton,
                darkMode && { backgroundColor: "#ffa500" },
              ]}
              onPress={() => setHelpModalVisible(false)}
            >
              <Text style={styles.modalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f2f2f2", padding: 20 },
  darkContainer: { backgroundColor: "#121212" },
  scrollContent: { alignItems: "center", paddingBottom: 40 },

  headingBar: {
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 12,
    paddingVertical: 14,
    marginBottom: 15,
    elevation: 4,
    alignItems: "center",
  },
  darkHeadingBar: { backgroundColor: "#1e1e1e" },

  title: { fontSize: 22, fontWeight: "700", color: "teal" },
  darkTitle: { color: "#ffa500" },

  subtitle: {
    fontSize: 14,
    color: "#555",
    marginBottom: 20,
    textAlign: "center",
  },
  darkSubtitle: { color: "#ccc" },

  buttonsContainer: { width: "100%" },

  button: {
    backgroundColor: "teal",
    paddingVertical: 14,
    borderRadius: 12,
    marginVertical: 8,
    alignItems: "center",
  },

  buttonText: { color: "#fff", fontWeight: "600", fontSize: 16 },

  footerText: { fontSize: 12, color: "#777", textAlign: "center" },
  darkFooter: { color: "#ccc" },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    padding: 20,
  },

  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 20,
  },

  darkModalContent: { backgroundColor: "#1e1e1e" },

  modalTitle: { fontSize: 20, fontWeight: "700", marginBottom: 10 },

  modalText: { fontSize: 14, marginBottom: 5, color: "#333" },

  darkText: { color: "#eee" },

  modalButton: {
    marginTop: 15,
    backgroundColor: "teal",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
  },

  modalButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },
});
