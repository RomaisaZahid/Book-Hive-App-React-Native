import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  FlatList,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { DrawerActions, useNavigation } from "@react-navigation/native";

const { width } = Dimensions.get("window"); // For responsive width

export default function DisplayMembersScreen() {
  const navigation = useNavigation();

  const [showForm, setShowForm] = useState(false);
  const [members, setMembers] = useState([
    {
      id: 1,
      fname: "Sara",
      lname: "Ahmed",
      email: "sara@gmail.com",
      phone: "0300-1234567",
    },
  ]);

  const [form, setForm] = useState({
    fname: "",
    lname: "",
    email: "",
    phone: "",
    reason: "",
  });

  const handleSave = () => {
    if (!form.fname || !form.email) return;

    const newMember = {
      id: members.length + 1,
      ...form,
    };

    setMembers([...members, newMember]);

    setForm({ fname: "", lname: "", email: "", phone: "", reason: "" });
    setShowForm(false);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 30 }}>
      
      {/* HEADER BAR */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
        >
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>  📋 Display Members</Text>
      </View>

      {/* MAIN CARD */}
      <View style={styles.glassCard}>
        <Text style={styles.mainHeading}>Library Volunteers</Text>

        {/* BUTTONS */}
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={[styles.mainButton, { flex: 1, marginRight: 8 }]}
            onPress={() => setShowForm(true)}
          >
            <Text style={styles.mainBtnText}>Add Member</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.lightButton, { flex: 1 }]}
            onPress={() => setShowForm(false)}
          >
            <Text style={styles.lightBtnText}>View Members</Text>
          </TouchableOpacity>
        </View>

        {/* ADD MEMBER FORM */}
        {showForm && (
          <View style={styles.innerCard}>
            <Text style={styles.cardHeading}>Add New Member</Text>

            {["fname", "lname", "email", "phone"].map((key) => (
              <View key={key} style={{ marginBottom: 12 }}>
                <Text style={styles.label}>
                  {key === "fname"
                    ? "First Name"
                    : key === "lname"
                    ? "Last Name"
                    : key === "email"
                    ? "Email"
                    : "Phone"}
                </Text>

                <TextInput
                  style={styles.input}
                  value={form[key]}
                  onChangeText={(v) => setForm({ ...form, [key]: v })}
                  placeholder={`Enter ${key}`}
                  placeholderTextColor="#aaa"
                />
              </View>
            ))}

            <Text style={styles.label}>Reason for Volunteering</Text>
            <TextInput
              style={[styles.input, { height: 80, textAlignVertical: "top" }]}
              value={form.reason}
              multiline
              onChangeText={(v) => setForm({ ...form, reason: v })}
              placeholder="Why do you want to volunteer?"
              placeholderTextColor="#aaa"
            />

            <TouchableOpacity style={styles.mainButton} onPress={handleSave}>
              <Text style={styles.mainBtnText}>💾 Save Member</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* MEMBERS LIST */}
        {!showForm && (
          <View style={styles.innerCard}>
            <Text style={styles.cardHeading}>Volunteers List</Text>

            <FlatList
              data={members}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View style={styles.memberCard}>
                  <Text style={styles.memberText}>
                    <Text style={styles.memberLabel}>Name: </Text>
                    {item.fname} {item.lname}
                  </Text>

                  <Text style={styles.memberText}>
                    <Text style={styles.memberLabel}>Email: </Text>
                    {item.email}
                  </Text>

                  <Text style={styles.memberText}>
                    <Text style={styles.memberLabel}>Phone: </Text>
                    {item.phone}
                  </Text>

                  <View style={styles.actionRow}>
                    <TouchableOpacity style={styles.editBtn}>
                      <Text style={styles.actionText}>Edit</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.deleteBtn}>
                      <Text style={styles.actionText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            />
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 15,
    backgroundColor: "#EAF9F7",
  },

  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    padding: 12,
    borderRadius: 15,
    elevation: 5,
    marginTop: 50,
    marginBottom: 20,
  },

  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#008080",
    marginLeft:  10,
    flexShrink: 1,
  },

  glassCard: {
    backgroundColor: "#FFFFFF",
    padding: 15,
    borderRadius: 20,
    elevation: 4,
  },

  mainHeading: {
    textAlign: "center",
    fontSize: 22,
    fontWeight: "700",
    color: "#008080",
    marginBottom: 15,
  },

  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },

  mainButton: {
    backgroundColor: "#FF7A00",
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 12,
    alignItems: "center",
  },

  mainBtnText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 16,
  },

  lightButton: {
    backgroundColor: "#FFFFFF",
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#008080",
    alignItems: "center",
  },

  lightBtnText: {
    fontWeight: "700",
    color: "#008080",
    fontSize: 16,
  },

  innerCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 15,
    padding: 15,
    marginTop: 10,
    elevation: 2,
  },

  cardHeading: {
    fontSize: 18,
    fontWeight: "700",
    color: "#008080",
    marginBottom: 10,
  },

  label: {
    fontWeight: "600",
    color: "#008080",
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: "#B0DCD6",
    borderRadius: 10,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 15,
  },

  memberCard: {
    backgroundColor: "#FDF7F1",
    padding: 12,
    marginBottom: 10,
    borderRadius: 12,
    elevation: 1,
  },

  memberText: {
    marginBottom: 4,
    fontSize: 15,
  },

  memberLabel: {
    fontWeight: "700",
    color: "#FF7A00",
  },

  actionRow: {
    flexDirection: "row",
    marginTop: 8,
  },

  editBtn: {
    backgroundColor: "#FFE0B8",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginRight: 8,
  },

  deleteBtn: {
    backgroundColor: "#FF6B6B",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },

  actionText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 14,
  },
});
