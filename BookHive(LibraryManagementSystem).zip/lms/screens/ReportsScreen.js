import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Dimensions,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BarChart } from "react-native-chart-kit";
import { Ionicons } from "@expo/vector-icons";
import { DrawerActions, useNavigation } from "@react-navigation/native";

const STORAGE_KEY = "LIBRARY_BOOKS";
const screenWidth = Dimensions.get("window").width;

export default function ReportsScreen() {
  const navigation = useNavigation();
  const [books, setBooks] = useState([]);

  /* ---------- LOAD DATA ---------- */
  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = async () => {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) setBooks(parsed);
      }
    } catch {
      Alert.alert("Error", "Failed to load data");
    }
  };

  /* ---------- DISABLED DOWNLOADS (SNACK LIMIT) ---------- */
  const snackLimit = () =>
    Alert.alert(
      "Not Supported",
      "CSV / PDF / Excel downloads are not supported in Expo Snack."
    );

  /* ---------- PRINT (WORKING SIMULATION) ---------- */
  const printReport = () => {
    if (books.length === 0)
      return Alert.alert("No Data", "Nothing to print");

    Alert.alert(
      "🖨 Print Preview",
      `Library Report\n\nTotal Books: ${books.length}\n\n(This simulates printer output in Expo Snack)`
    );
  };

  /* ---------- CHART DATA ---------- */
  const chartData = {
    labels: books.map((b, i) =>
      b?.title ? b.title.slice(0, 5) : `B${i + 1}`
    ),
    datasets: [
      {
        data: books.map((b) => Number(b.quantity) || 0),
      },
    ],
  };

  return (
    <ScrollView style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
        >
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>
        <Text style={styles.title}>📊 Reports</Text>
      </View>

      {/* CHART */}
      {books.length > 0 ? (
        <>
          <Text style={styles.section}>Books Quantity Overview</Text>

          <BarChart
            data={chartData}
            width={screenWidth - 30}
            height={260}
            fromZero
            showValuesOnTopOfBars
            chartConfig={{
              backgroundGradientFrom: "#ffffff",
              backgroundGradientTo: "#ffffff",
              decimalPlaces: 0,
              barPercentage: 0.6,
              color: () => "#008080",
              labelColor: () => "#333",
              propsForBackgroundLines: {
                strokeDasharray: "",
                stroke: "#eee",
              },
            }}
            style={styles.chart}
          />
        </>
      ) : (
        <Text style={styles.noData}>No report data available</Text>
      )}

      {/* ACTIONS */}
      <View style={styles.actions}>
        <DisabledButton text="📄 Generate PDF" onPress={snackLimit} />
        <DisabledButton text="📊 Generate CSV" onPress={snackLimit} />
        <DisabledButton text="📗 Generate Excel" onPress={snackLimit} />
        <ActionButton text="🖨 Print Report" onPress={printReport} />
      </View>
    </ScrollView>
  );
}

/* ---------- BUTTONS ---------- */
const ActionButton = ({ text, onPress }) => (
  <TouchableOpacity style={styles.btn} onPress={onPress}>
    <Text style={styles.btnText}>{text}</Text>
  </TouchableOpacity>
);

const DisabledButton = ({ text, onPress }) => (
  <TouchableOpacity style={styles.btnDisabled} onPress={onPress}>
    <Text style={styles.btnText}>{text}</Text>
  </TouchableOpacity>
);

/* ---------- STYLES ---------- */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#E6F4F1",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 15,
    marginTop: 50,
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#008080",
    marginLeft: 10,
  },
  section: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 15,
    color: "#004D4D",
  },
  chart: {
    borderRadius: 16,
    paddingVertical: 10,
  },
  noData: {
    textAlign: "center",
    marginTop: 40,
    fontSize: 16,
    color: "#555",
  },
  actions: {
    marginTop: 25,
  },
  btn: {
    backgroundColor: "#008080",
    padding: 15,
    borderRadius: 12,
    marginBottom: 12,
    alignItems: "center",
  },
  btnDisabled: {
    backgroundColor: "#9fbfbf",
    padding: 15,
    borderRadius: 12,
    marginBottom: 12,
    alignItems: "center",
  },
  btnText: {
    color: "#fff",
    fontWeight: "700",
  },
});
