import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createDrawerNavigator } from "@react-navigation/drawer";

// Screens
import WelcomeScreen from "./screens/WelcomeScreen";
import SignInScreen from "./screens/SignInScreen";
import SignUpScreen from "./screens/SignUpScreen";
import DashboardScreen from "./screens/DashBoardScreen";
import BooksScreen from "./screens/BooksScreen";
import MembersScreen from "./screens/MembersScreen";
import IssuedBooksScreen from "./screens/IssuedBooksScreen";
import SettingsScreen from "./screens/SettingsScreen";
import ReturnBooksScreen from "./screens/ReturnBooksScreen";
import DisplayMembersScreen from "./screens/DisplayMembersScreen";
import ReportsScreen from "./screens/ReportsScreen";
import ProfileScreen from "./screens/ProfileScreen";
import LogoutScreen from "./screens/LogoutScreen"; // ✅ Import new LogoutScreen

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

// 🧭 Drawer Navigator for Dashboard
function DashboardDrawer() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        drawerStyle: { backgroundColor: "#E8F7F6", width: 260 },
        drawerActiveBackgroundColor: "#008080",
        drawerActiveTintColor: "#ffffff",
        drawerInactiveTintColor: "#444",
        drawerLabelStyle: { fontSize: 16, fontWeight: "600" },
        drawerItemStyle: { borderRadius: 14, marginVertical: 5 },
      }}
    >
      <Drawer.Screen name="Dashboard" component={DashboardScreen} />
      <Drawer.Screen name="Books" component={BooksScreen} />
      <Drawer.Screen name="Members" component={MembersScreen} />
      <Drawer.Screen name="Display Members" component={DisplayMembersScreen} />
      <Drawer.Screen name="Issued Books" component={IssuedBooksScreen} />
      <Drawer.Screen name="Return Books" component={ReturnBooksScreen} />
      <Drawer.Screen name="Reports" component={ReportsScreen} />
      <Drawer.Screen name="Settings" component={SettingsScreen} />
      <Drawer.Screen
        name="Logout"
        component={LogoutScreen}
        options={{
          drawerLabelStyle: { color: "#ff6b00", fontWeight: "700" },
          drawerItemStyle: { backgroundColor: "transparent" },
        }}
      />
    </Drawer.Navigator>
  );
}

// 🔹 Main App Navigator
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="SignIn" component={SignInScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />

        {/* Dashboard with Drawer */}
        <Stack.Screen name="Dashboard" component={DashboardDrawer} />

        {/* ✅ Profile Screen added to Stack */}
        <Stack.Screen name="Profile" component={ProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
